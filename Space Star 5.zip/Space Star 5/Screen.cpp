#include "Screen.h"


CScreen::CScreen(void)
{

}


CScreen::~CScreen(void)
{
}
